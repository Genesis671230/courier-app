<?php
namespace App\Enums;

interface SalaryStatus
{
    const UNPAID                             = 0;
    const PAID                               = 1;
    const PARTIAL_PAID                       = 2;

}
