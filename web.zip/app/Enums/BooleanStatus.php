<?php

namespace App\Enums;


interface BooleanStatus
{
    const NO  = 0;
    const YES = 1;
}
