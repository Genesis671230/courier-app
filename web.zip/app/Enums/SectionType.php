<?php
namespace App\Enums;
interface SectionType{
    const BANNER        = 1;
    const ACHIEVEMENT   = 2;
    const ABOUT         = 3;
    const SUBSCRIBE     = 4;
    const APP_LINK      = 5; 
    const MAP_LINK      = 6; 
}