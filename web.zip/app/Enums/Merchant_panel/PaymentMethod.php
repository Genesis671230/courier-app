<?php
namespace App\Enums\Merchant_panel;

interface PaymentMethod{
    const bank   = 'bank';
    const mobile = 'mobile';
    const cash   = 'cash';
}
