<?php

namespace App\Enums;


interface StatementType
{
    const INCOME  = 1;
    const EXPENSE = 2;
}
