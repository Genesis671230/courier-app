<?php
namespace App\Enums;
Interface AccountType
{

        const ADMIN    = 1;
        const USER     = 2;

}
