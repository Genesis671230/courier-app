<?php
namespace App\Enums;

interface TodoStatus
{
    const   PENDING     = 1;
    const   PROCESSING  = 2;
    const   COMPLETED   = 3;

}
