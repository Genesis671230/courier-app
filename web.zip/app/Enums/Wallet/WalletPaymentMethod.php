<?php
namespace App\Enums\Wallet;
interface WalletPaymentMethod{
    const OFFLINE  = 1;
    const WALLET   = 2;
    // const STRIPE  = 2;
    // const PAYPAL  = 2;
    // const SKRILL  = 2;
}