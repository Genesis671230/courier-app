<?php
namespace App\Enums\Wallet;
interface WalletType{
    const INCOME  = 1;
    const EXPENSE = 2;
}