<?php
namespace App\Enums;
Interface AccountHeads
{

        const INCOME    = 1;
        const EXPENSE   = 2;

}
