<?php
namespace App\Enums;

interface SmsSetup {
    const REVE     = 1;//
    CONST TWILIO   = 2;//
    CONST NEXMO    = 3;//
}
