<?php
namespace App\Enums;

Interface PickupRequestType{
    const REGULAR = 1;
    const EXPRESS = 2;

}
