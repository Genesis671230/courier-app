<?php
namespace App\Repositories\GoogleMapSettings;

interface GoogleMapSettingsInterface {

    public function all();
    public function update($request);

}
