<?php
namespace App\Repositories\GeneralSettings;

interface GeneralSettingsInterface {

    public function all();
    public function update($request);

}
