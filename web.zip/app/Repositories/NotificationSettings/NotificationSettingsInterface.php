<?php
namespace App\Repositories\NotificationSettings;

interface NotificationSettingsInterface {

    public function all();
    public function update($request);

}
